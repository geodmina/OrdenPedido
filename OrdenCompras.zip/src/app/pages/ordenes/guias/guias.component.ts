import { Component, OnInit } from '@angular/core';
import { OrdenService } from '../../../services/service.index';

@Component({
  selector: 'app-guias',
  templateUrl: './guias.component.html',
  styleUrls: ['./guias.component.scss']
})
export class GuiasComponent implements OnInit {

  guias = [];
  guia;
  indice = 0;
  loading = true;
  currentDate = new Date();
  oculto = 'oculto';

  constructor(
    private ordenService: OrdenService,
  ) { }

  ngOnInit() {
    this.currentDate.setDate(this.currentDate.getDate() - 1);
    this.getGuias();
  }

  getGuias() {
    this.ordenService.getGuias().subscribe(facturas => {
      this.guias = facturas.map(e => {
        return {
          uid: e.payload.doc.id,
          ...e.payload.doc.data()
        };
      });
      this.loading = false;
    });
  }

  mostrar(guia: any, i) {
    this.oculto = '';
    this.guia = guia;
    this.indice = i;
  }

}
