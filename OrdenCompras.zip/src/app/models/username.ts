export class Username {

    uid?: string;
    name?: string;
    email?: string;
    role?: string;
    fechaNacimiento?: string;
    edad?: number;
    fechaIngreso?: string;
    fechaBaja?: string;
    status?: string;
}
