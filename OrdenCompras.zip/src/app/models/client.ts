export class Client {

    id?: string;
    ruc?: string;
    name?: string;
    lastname?: string;
    image?: string;
    city?: string;
    address?: string;
    phone?: string;
    seller?: string;
    should?: boolean;
    status?: boolean;
    cm?: number;
    cu?: number;
    email?: string;

}
