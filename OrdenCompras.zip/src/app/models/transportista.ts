export class Transportista {

    nuc?: string;
    name?: string;
    plaque?: string;
}
