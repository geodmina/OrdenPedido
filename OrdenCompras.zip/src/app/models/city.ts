export class City {

    name?: string;

}
