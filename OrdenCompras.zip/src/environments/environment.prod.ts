export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyARNWC-h20iHtUaOL_9D7BGNHGwvx4fY1s',
    authDomain: 'orden-pedidos.firebaseapp.com',
    databaseURL: 'https://orden-pedidos.firebaseio.com',
    projectId: 'orden-pedidos',
    storageBucket: 'orden-pedidos.appspot.com',
    messagingSenderId: '544672712834'
  }
};
